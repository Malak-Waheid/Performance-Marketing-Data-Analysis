import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

# === Load your CSVs or SQL data ===
data = pd.read_csv(r'PerformanceMarketing.csv')
data = data.head(1000)

# === Clean the 'Budget' and Revenue_Generated column ===
data['Budget'] = data['Budget'].replace('[\$,]', '', regex=True).astype(float)
data['Revenue_Generated'] = data['Revenue_Generated'].replace('[\$,]', '', regex=True).astype(float)

# === Group by Customer to build features ===
customer_features = data.groupby('Campaign_ID').agg({
    'Budget': 'sum',
    'Conversions': 'sum',
    'Revenue_Generated': 'sum',
    'ROI': 'mean',
})


# Flatten multi-index columns
customer_features.columns = ['TotalBudget', 'TotalConversions', 'TotalRevenue', 'AverageROI']
customer_features.reset_index(inplace=True)


# === Select features for clustering ===
X = customer_features[['TotalBudget', 'TotalConversions', 'TotalRevenue', 'AverageROI']]


# === Scale the data ===
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)


# === Apply Elbow Method ====
inertia = []
k_clusters = range(1,10)
for k in k_clusters: #for loop to calculate inertia for each k
    num_clusters = k
    kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init=10)
    kmeans.fit(X_scaled)
    customer_features['cluster'] = kmeans.labels_
    inertia.append(kmeans.inertia_) #we are adding to the inertia list
#Inertia = Sum of Squared Distances from each point to its assigned cluster center.


# === Visualize Elbow Method Results ===
plt.plot(k_clusters, inertia, marker='o')
plt.xlabel('Number of clusters (K)')
plt.ylabel('Inertia')
plt.title('Elbow Method for Optimal K')
plt.show()


# === Calculate K-Mean with optimal k (number of clusters) ===
num_clusters = 2
kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init=10)
kmeans.fit(X_scaled)
customer_features['cluster'] = kmeans.labels_


# === Apply PCA (dimentionality reduction) ===
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)


# === Visualize clusters with PCA ===
plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=customer_features['cluster'], cmap='viridis')
plt.title('Campaign Segments')
plt.xlabel('PCA 1')
plt.ylabel('PCA 2')
plt.colorbar(label='Cluster')
plt.show()